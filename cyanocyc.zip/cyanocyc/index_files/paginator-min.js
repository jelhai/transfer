/*
YUI 3.17.2 (build 9c3c78e)
Copyright 2014 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/

YUI.add("paginator",function(e,t){e.Paginator=e.mix(e.Base.create("paginator",e.Base,[e.Paginator.Core]),e.Paginator)},"3.17.2",{requires:["paginator-core"]});
