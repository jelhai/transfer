var userInfo = {"id":61489,"name":"Jeff Elhai","email":"elhaij@vcu.edu"};
var subscriptionInfo = [{"name":"Jeff Elhai","endDate":"2024-07-24","subscriptionType":"user"}];
var preferred_database = 'GCF_000234725';
var can_create_group = true;
var multiorg_initiallySelected =null;