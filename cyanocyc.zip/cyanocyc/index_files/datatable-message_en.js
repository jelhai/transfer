/*
YUI 3.17.2 (build 9c3c78e)
Copyright 2014 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/

YUI.add("lang/datatable-message_en",function(e){e.Intl.add("datatable-message","en",{emptyMessage:"No data to display",loadingMessage:"Loading..."})},"3.17.2");
